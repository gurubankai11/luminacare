import { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom'
import { supabase } from './lib/supabase'
import { AnimatePresence } from 'framer-motion'
import { Toaster } from 'react-hot-toast'

// Shared
import Loader from './components/shared/Loader'

// Public pages
import HomePage from './pages/HomePage'
import AboutPage from './pages/AboutPage'
import ServicesPage from './pages/ServicesPage'
import DoctorsPage from './pages/DoctorsPage'
import BranchesPage from './pages/BranchesPage'
import ContactPage from './pages/ContactPage'
import BookAppointmentPage from './pages/BookAppointmentPage'
import SettingsPage from './pages/SettingsPage'
import NotFoundPage from './pages/NotFoundPage'
import { PrivacyPage, TermsPage } from './pages/LegalPages'

// Auth pages
import LoginPage from './pages/auth/LoginPage'

// Dashboards
import PatientDashboard from './pages/patient/PatientDashboard'
import DoctorDashboard from './pages/doctor/DoctorDashboard'
import ReceptionDashboard from './pages/reception/ReceptionDashboard'
import AdminDashboard from './pages/admin/AdminDashboard'

import { useAuthStore } from './stores/authStore'
import { Navigate } from 'react-router-dom'

function ProtectedRoute({ children, allowedRoles }: { children: React.ReactNode, allowedRoles?: string[] }) {
  const { isAuthenticated, user, isLoading } = useAuthStore()

  if (isLoading) return <Loader onComplete={() => {}} />

  if (!isAuthenticated) {
    return <Navigate to="/login/patient" replace />
  }

  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    return <Navigate to="/" replace />
  }

  return <>{children}</>
}

/* ─── Animated Routes ─── */
function AnimatedRoutes() {
  const location = useLocation()
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        {/* Public */}
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/doctors" element={<DoctorsPage />} />
        <Route path="/branches" element={<BranchesPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/book-appointment" element={<BookAppointmentPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="/terms" element={<TermsPage />} />

        {/* Auth */}
        <Route path="/login/patient" element={<LoginPage role="patient" />} />
        <Route path="/login/doctor" element={<LoginPage role="doctor" />} />
        <Route path="/login/reception" element={<LoginPage role="reception" />} />
        <Route path="/login/admin" element={<LoginPage role="admin" />} />

        {/* Dashboards */}
        <Route path="/dashboard/patient/*" element={<ProtectedRoute allowedRoles={['patient']}><PatientDashboard /></ProtectedRoute>} />
        <Route path="/dashboard/doctor/*" element={<ProtectedRoute allowedRoles={['doctor']}><DoctorDashboard /></ProtectedRoute>} />
        <Route path="/dashboard/reception/*" element={<ProtectedRoute allowedRoles={['reception', 'admin']}><ReceptionDashboard /></ProtectedRoute>} />
        <Route path="/dashboard/admin/*" element={<ProtectedRoute allowedRoles={['admin']}><AdminDashboard /></ProtectedRoute>} />

        {/* 404 */}
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </AnimatePresence>
  )
}

/* ─── App Root ─── */
function AppContent() {
  const [loading, setLoading] = useState(true)
  const { refreshUser } = useAuthStore()

  useEffect(() => {
    refreshUser()
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, _session) => {
      refreshUser()
    })
    return () => subscription.unsubscribe()
  }, [refreshUser])

  return (
    <>
      {loading && <Loader onComplete={() => setLoading(false)} />}
      {!loading && <AnimatedRoutes />}
    </>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: 'var(--card)',
            color: 'var(--text-primary)',
            borderRadius: '12px',
            border: '1px solid var(--border)',
            boxShadow: '0 8px 30px rgba(0,0,0,0.08)',
            fontFamily: 'Inter, sans-serif',
            fontSize: '14px',
          },
        }}
      />
    </BrowserRouter>
  )
}
