import { useState, useEffect, type ReactNode } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Link, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard, Calendar, Clock, Pill, FileText, MessageSquare,
  Bell, Settings, User, LogOut, Activity,
  CheckCircle, AlertCircle, XCircle, Download, Send, Paperclip,
  Menu, X
} from 'lucide-react'
import { useAuthStore } from '../../stores/authStore'
import { Avatar, Badge } from '../../components/ui'
import Card, { StatCard } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input from '../../components/ui/Input'
import { useChatStore } from '../../stores/chatStore'
import { useNotificationStore } from '../../stores/notificationStore'
import { useAppointmentStore } from '../../stores/appointmentStore'
import { useMedicalStore } from '../../stores/medicalStore'
import { cn, formatDate, formatTime } from '../../lib/utils'

/* ─── Sidebar Nav ─── */
const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'appointments', label: 'Appointments', icon: Calendar },
  { id: 'queue', label: 'Live Queue', icon: Clock },
  { id: 'medicines', label: 'Prescriptions', icon: Pill },
  { id: 'reports', label: 'Test Reports', icon: FileText },
  { id: 'chat', label: 'Chat', icon: MessageSquare },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'settings', label: 'Settings', icon: Settings },
]


const STATUS_CONFIG = {
  confirmed: { label: 'Confirmed', variant: 'accent' as const, icon: CheckCircle },
  completed: { label: 'Completed', variant: 'success' as const, icon: CheckCircle },
  pending: { label: 'Pending', variant: 'warning' as const, icon: AlertCircle },
  cancelled: { label: 'Cancelled', variant: 'danger' as const, icon: XCircle },
}

/* ─── Sidebar ─── */
function Sidebar({ active, onNavigate, onClose }: { active: string; onNavigate: (id: string) => void; onClose?: () => void }) {
  const { user, signOut } = useAuthStore()
  const navigate = useNavigate()

  const handleSignOut = async () => {
    await signOut()
    navigate('/')
  }

  return (
    <div className="flex flex-col h-full bg-white dark:bg-neutral-900 border-r border-border-light dark:border-border-dark">
      {/* Logo */}
      <div className="p-5 border-b border-border-light dark:border-border-dark">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-accent-500 flex items-center justify-center shadow-glow-accent-sm">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L4 7V17L12 22L20 17V7L12 2Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M12 8V16M8 12H16" stroke="white" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>
          <span className="font-manrope font-bold text-base text-neutral-900 dark:text-neutral-100">
            Lumina<span className="text-accent-500">Care</span>
          </span>
          {onClose && (
            <button onClick={onClose} className="ml-auto p-1.5 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-400">
              <X size={16} />
            </button>
          )}
        </div>
      </div>

      {/* User info */}
      <div className="px-4 py-4 border-b border-border-light dark:border-border-dark">
        <div className="flex items-center gap-3">
          <Avatar name={user?.name || 'Patient'} status="online" />
          <div className="min-w-0">
            <p className="font-semibold text-body-sm text-neutral-900 dark:text-neutral-100 truncate">{user?.name || 'Demo Patient'}</p>
            <p className="text-caption text-neutral-400 truncate">{user?.email || 'patient@demo.in'}</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto" aria-label="Patient dashboard navigation">
        {NAV_ITEMS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => { onNavigate(id); onClose?.() }}
            className={cn(
              'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-body-sm font-medium transition-all duration-200',
              active === id
                ? 'bg-accent-50 dark:bg-accent-500/10 text-accent-600 dark:text-accent-400'
                : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 hover:text-neutral-900 dark:hover:text-neutral-100'
            )}
          >
            <Icon size={16} className="flex-shrink-0" />
            {label}
          </button>
        ))}
      </nav>

      {/* Sign out */}
      <div className="p-3 border-t border-border-light dark:border-border-dark">
        <button
          onClick={handleSignOut}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-body-sm font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-500/10 transition-all duration-200"
        >
          <LogOut size={16} />
          Sign Out
        </button>
      </div>
    </div>
  )
}

/* ─── Section Components ─── */
function DashboardHome() {
  const { notifications } = useNotificationStore()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-manrope font-bold text-display-sm text-neutral-900 dark:text-neutral-100">Welcome back 👋</h1>
        <p className="text-body-md text-neutral-500 dark:text-neutral-400 mt-1">Here's your health overview for today.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Upcoming" value="2" change="Appointments" changeType="neutral" icon={<Calendar size={20} />} />
        <StatCard label="Queue Position" value="#3" change="~15 min wait" changeType="neutral" icon={<Clock size={20} />} />
        <StatCard label="Active Prescriptions" value="1" change="Review due" changeType="neutral" icon={<Pill size={20} />} />
        <StatCard label="Reports" value="3" change="1 needs review" changeType="down" icon={<FileText size={20} />} />
      </div>

      {/* Next appointment */}
      <Card className="border-accent-200 dark:border-accent-500/30 bg-gradient-to-br from-accent-50 to-white dark:from-accent-500/10 dark:to-neutral-900">
        <div className="flex items-center justify-between mb-1">
          <p className="text-caption text-neutral-500 uppercase tracking-wide font-medium">Next Appointment</p>
          <Badge variant="accent" dot>Confirmed</Badge>
        </div>
        <div className="flex items-start justify-between mt-3">
          <div>
            <p className="font-manrope font-bold text-heading-xl text-neutral-900 dark:text-neutral-100">Dr. Arjun Mehta</p>
            <p className="text-body-sm text-accent-600 dark:text-accent-400 font-medium">Cardiologist</p>
            <p className="text-body-sm text-neutral-500 dark:text-neutral-400 mt-2 flex items-center gap-2">
              <Calendar size={14} />
              July 15, 2026 at 10:30 AM
            </p>
          </div>
          <div className="text-center">
            <p className="text-caption text-neutral-400">Token</p>
            <p className="font-manrope font-bold text-display-sm text-accent-500">#3</p>
          </div>
        </div>
      </Card>

      {/* Recent notifications */}
      <div>
        <h2 className="section-title text-xl mb-4">Recent Notifications</h2>
        <div className="space-y-3">
          {notifications.slice(0, 2).map(n => (
            <div key={n.notification_id} className={cn('flex gap-3 p-4 rounded-2xl border', n.read ? 'bg-white dark:bg-neutral-900 border-border-light dark:border-border-dark' : 'bg-accent-50 dark:bg-accent-500/10 border-accent-200 dark:border-accent-500/20')}>
              <div className="w-8 h-8 rounded-xl bg-accent-100 dark:bg-accent-500/20 flex items-center justify-center flex-shrink-0">
                <Bell size={14} className="text-accent-500" />
              </div>
              <div className="min-w-0">
                <p className="text-body-sm font-semibold text-neutral-900 dark:text-neutral-100">{n.title}</p>
                <p className="text-body-sm text-neutral-500 dark:text-neutral-400 truncate">{n.message}</p>
                <p className="text-caption text-neutral-400 mt-1">{formatDate(n.created_at)}</p>
              </div>
              {!n.read && <div className="w-2 h-2 rounded-full bg-accent-500 flex-shrink-0 mt-2" />}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function AppointmentsSection() {
  const { appointments } = useAppointmentStore()

  return (
    <div className="space-y-6">
      <h1 className="page-title text-2xl">My Appointments</h1>
      <div className="space-y-4">
        {appointments.map(appt => {
          const status = STATUS_CONFIG[appt.status as keyof typeof STATUS_CONFIG] || STATUS_CONFIG.pending
          return (
            <Card key={appt.appointment_id} className="hover:shadow-soft-md transition-shadow">
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-accent-50 dark:bg-accent-500/10 flex items-center justify-center flex-shrink-0">
                    <Activity size={22} className="text-accent-500" />
                  </div>
                  <div>
                    <p className="font-semibold text-neutral-900 dark:text-neutral-100">{appt.profiles?.name || 'Doctor'}</p>
                    <p className="text-body-sm text-accent-500 font-medium">Consultation</p>
                    <p className="text-caption text-neutral-400 mt-0.5 flex items-center gap-1.5">
                      <Calendar size={11} /> {formatDate(appt.date)} at {formatTime(appt.time)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <p className="text-caption text-neutral-400">Token</p>
                    <p className="font-manrope font-bold text-heading-md text-accent-500">#{appt.queue_token}</p>
                  </div>
                  <Badge variant={status.variant} dot>{status.label}</Badge>
                </div>
              </div>
            </Card>
          )
        })}
        {appointments.length === 0 && <p className="text-neutral-500 py-4">No appointments found.</p>}
      </div>
    </div>
  )
}

function QueueSection() {
  const { todayQueue } = useAppointmentStore()
  
  return (
    <div className="space-y-6">
      <h1 className="page-title text-2xl">Live Queue</h1>
      <Card className="border-accent-200 dark:border-accent-500/30">
        <div className="text-center py-4">
          <p className="text-caption text-neutral-500 uppercase tracking-widest mb-2">Current Queue Status</p>
          <p className="font-manrope font-extrabold text-5xl text-accent-500 mb-2">{todayQueue.length} Patients</p>
          <Badge variant="success" dot>Active</Badge>
        </div>
      </Card>
      <Card>
        <h2 className="font-semibold text-heading-md text-neutral-900 dark:text-neutral-100 mb-4">Today's Tokens</h2>
        <div className="space-y-3">
          {todayQueue.map(p => (
            <div key={p.appointment_id} className={cn('flex items-center gap-3 p-3 rounded-xl', p.status === 'in_progress' ? 'bg-accent-50 dark:bg-accent-500/10 border border-accent-200 dark:border-accent-500/20' : 'bg-neutral-50 dark:bg-neutral-800')}>
              <span className={cn('font-manrope font-bold w-8 text-center', p.status === 'in_progress' ? 'text-accent-600 dark:text-accent-400' : 'text-neutral-400')}>{p.queue_token}</span>
              <p className={cn('text-body-sm', p.status === 'in_progress' ? 'font-semibold text-neutral-900 dark:text-neutral-100' : 'text-neutral-500')}>
                {p.profiles?.name || 'Patient'}
              </p>
              {p.status === 'in_progress' && <Badge variant="success" size="sm" className="ml-auto">In Progress</Badge>}
              {p.status === 'completed' && <Badge variant="neutral" size="sm" className="ml-auto">Completed</Badge>}
              {p.status === 'pending' && <Badge variant="warning" size="sm" className="ml-auto">Pending</Badge>}
            </div>
          ))}
          {todayQueue.length === 0 && <p className="text-neutral-500 text-center py-4">No queue data for today.</p>}
        </div>
      </Card>
    </div>
  )
}

function MedicinesSection() {
  const { prescriptions } = useMedicalStore()
  return (
    <div className="space-y-6">
      <h1 className="page-title text-2xl">Prescriptions</h1>
      {prescriptions.map(rx => (
        <Card key={rx.prescription_id} className="space-y-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="font-manrope font-bold text-heading-md text-neutral-900 dark:text-neutral-100">{rx.instructions?.split("\n")[0]?.replace("Diagnosis: ", "") || "Prescription"}</p>
              <p className="text-body-sm text-accent-600 dark:text-accent-400 font-medium mt-0.5">{rx.profiles?.name}</p>
              <p className="text-caption text-neutral-400 mt-0.5">{formatDate(rx.created_at)}</p>
            </div>
            <Button variant="outline" size="sm" leftIcon={<Download size={14} />}>
              Download PDF
            </Button>
          </div>

          <div className="border border-border-light dark:border-border-dark rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-neutral-50 dark:bg-neutral-800">
                <tr>
                  <th className="text-left px-4 py-2.5 text-caption font-semibold text-neutral-500 uppercase tracking-wide">Medicine</th>
                  <th className="text-center px-3 py-2.5 text-caption font-semibold text-neutral-500 uppercase tracking-wide">Morning</th>
                  <th className="text-center px-3 py-2.5 text-caption font-semibold text-neutral-500 uppercase tracking-wide">Afternoon</th>
                  <th className="text-center px-3 py-2.5 text-caption font-semibold text-neutral-500 uppercase tracking-wide">Night</th>
                  <th className="text-left px-4 py-2.5 text-caption font-semibold text-neutral-500 uppercase tracking-wide">Duration</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border-light dark:divide-border-dark">
                {rx.medicine?.map(med => (
                  <tr key={med.name}>
                    <td className="px-4 py-3 font-medium text-neutral-900 dark:text-neutral-100">{med.name}</td>
                    <td className="px-3 py-3 text-center">{med.morning ? '✅' : '—'}</td>
                    <td className="px-3 py-3 text-center">{med.afternoon ? '✅' : '—'}</td>
                    <td className="px-3 py-3 text-center">{med.night ? '✅' : '—'}</td>
                    <td className="px-4 py-3 text-neutral-500 dark:text-neutral-400">{med.duration}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {rx.instructions && (
            <div className="bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 rounded-xl p-4">
              <p className="text-body-sm font-semibold text-amber-700 dark:text-amber-400 mb-1">Special Instructions</p>
              <p className="text-body-sm text-amber-700 dark:text-amber-300">{rx.instructions}</p>
            </div>
          )}
        </Card>
      ))}
      {prescriptions.length === 0 && <p className="text-neutral-500 py-4">No prescriptions found.</p>}
    </div>
  )
}

function ReportsSection() {
  const { records } = useMedicalStore()
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="page-title text-2xl">Test Reports</h1>
        <Button variant="outline" size="sm">Upload Report</Button>
      </div>
      <div className="space-y-3">
        {records.map(report => (
          <Card key={report.report_id} className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-accent-50 dark:bg-accent-500/10 flex items-center justify-center flex-shrink-0">
              <FileText size={22} className="text-accent-500" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-neutral-900 dark:text-neutral-100">{report.file}</p>
              <p className="text-body-sm text-neutral-500 dark:text-neutral-400">{report.report_type} · {formatDate(report.created_at)}</p>
            </div>
            <Badge variant={report.status === 'normal' ? 'success' : 'warning'} dot>
              {report.status === 'normal' ? 'Normal' : 'Review'}
            </Badge>
            <Button variant="ghost" size="sm" leftIcon={<Download size={13} />}>PDF</Button>
          </Card>
        ))}
        {records.length === 0 && <p className="text-neutral-500 py-4">No reports found.</p>}
      </div>
    </div>
  )
}

function ChatSection() {
  const { messages, fetchMessages, sendMessage, subscribeToMessages } = useChatStore()
  const { user } = useAuthStore()
  const { appointments } = useAppointmentStore()
  const [message, setMessage] = useState('')

  const doctorId = appointments.find(a => a.doctor_id)?.doctor_id
  const doctorName = appointments.find(a => a.doctor_id)?.profiles?.name || 'Assigned Doctor'
  useEffect(() => {
    if (user?.id && doctorId) {
      fetchMessages(user.id, doctorId)
      const unsubscribe = subscribeToMessages(user.id, doctorId)
      return () => unsubscribe()
    }
  }, [fetchMessages, subscribeToMessages, user?.id, doctorId])

  const handleSend = () => {
    if (!message.trim() || !doctorId) return
    sendMessage(message, doctorId)
    setMessage('')
  }

  return (
    <div className="space-y-4 flex flex-col h-full">
      <h1 className="page-title text-2xl">Chat</h1>
      <Card className="flex-1 flex flex-col">
        <div className="flex items-center gap-3 pb-4 border-b border-border-light dark:border-border-dark">
          <Avatar name={doctorName} status="online" />
          <div>
            <p className="font-semibold text-neutral-900 dark:text-neutral-100">{doctorName}</p>
            <p className="text-caption text-emerald-500 flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />Online</p>
          </div>
        </div>

        <div className="flex-1 space-y-4 py-4 overflow-y-auto min-h-[300px] max-h-[400px]">
          {messages.map(msg => {
            const isMe = msg.sender_id === user?.id
            return (
              <div key={msg.message_id} className={cn('flex gap-3', isMe ? 'flex-row-reverse' : 'flex-row')}>
                {!isMe && <Avatar name={doctorName} size="sm" />}
                <div className={cn('max-w-xs rounded-2xl px-4 py-3 text-body-sm',
                  isMe
                    ? 'bg-accent-500 text-white rounded-tr-sm'
                    : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-900 dark:text-neutral-100 rounded-tl-sm'
                )}>
                  <p>{msg.message}</p>
                  <p className={cn('text-xs mt-1', isMe ? 'text-blue-100' : 'text-neutral-400')}>{formatTime(msg.created_at)}</p>
                </div>
              </div>
            )
          })}
        </div>

        <div className="flex items-center gap-2 pt-4 border-t border-border-light dark:border-border-dark">
          <button className="p-2 rounded-xl text-neutral-400 hover:text-accent-500 hover:bg-accent-50 dark:hover:bg-accent-500/10 transition-colors">
            <Paperclip size={18} />
          </button>
          <div className="flex-1">
            <Input
              placeholder="Type a message..."
              value={message}
              onChange={e => setMessage(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSend()}
            />
          </div>
          <Button variant="primary" size="sm" className="rounded-xl" rightIcon={<Send size={14} />} onClick={handleSend}>
            Send
          </Button>
        </div>
      </Card>
    </div>
  )
}

function NotificationsSection() {
  const { notifications, fetchNotifications, markAsRead, subscribeToNotifications } = useNotificationStore()

  useEffect(() => {
    fetchNotifications()
    const unsubscribe = subscribeToNotifications()
    return () => unsubscribe()
  }, [fetchNotifications, subscribeToNotifications])

  return (
    <div className="space-y-6">
      <h1 className="page-title text-2xl">Notifications</h1>
      <div className="space-y-3">
        {notifications.map(n => (
          <div key={n.notification_id} onClick={() => !n.read && markAsRead(n.notification_id)} className={cn('flex gap-4 p-4 rounded-2xl border cursor-pointer transition-colors', n.read ? 'bg-white dark:bg-neutral-900 border-border-light dark:border-border-dark hover:bg-neutral-50 dark:hover:bg-neutral-800' : 'bg-accent-50 dark:bg-accent-500/10 border-accent-200 dark:border-accent-500/20')}>
            <div className="w-10 h-10 rounded-xl bg-accent-100 dark:bg-accent-500/20 flex items-center justify-center flex-shrink-0">
              <Bell size={18} className="text-accent-500" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-neutral-900 dark:text-neutral-100">{n.title}</p>
              <p className="text-body-sm text-neutral-600 dark:text-neutral-400 mt-0.5">{n.message}</p>
              <p className="text-caption text-neutral-400 mt-1">{formatDate(n.created_at)}</p>
            </div>
            {!n.read && <div className="w-2.5 h-2.5 rounded-full bg-accent-500 flex-shrink-0 mt-1.5" />}
          </div>
        ))}
        {notifications.length === 0 && <p className="text-neutral-500 text-center py-8">No new notifications</p>}
      </div>
    </div>
  )
}

function ProfileSection() {
  const { user } = useAuthStore()
  return (
    <div className="space-y-6">
      <h1 className="page-title text-2xl">My Profile</h1>
      <Card className="flex items-center gap-5">
        <Avatar name={user?.name || 'Patient'} size="2xl" />
        <div>
          <p className="font-manrope font-bold text-heading-xl text-neutral-900 dark:text-neutral-100">{user?.name || 'Demo Patient'}</p>
          <p className="text-body-sm text-neutral-500 dark:text-neutral-400">{user?.email || 'patient@demo.in'}</p>
          <Badge variant="accent" dot className="mt-2">Patient</Badge>
        </div>
        <Button variant="outline" size="sm" className="ml-auto">Edit Profile</Button>
      </Card>
      <div className="grid sm:grid-cols-2 gap-4">
        {[['Phone', user?.phone || '+91 98765 43210'], ['Blood Group', 'B+'], ['Date of Birth', 'Jan 15, 1990'], ['Allergies', 'None known']].map(([label, value]) => (
          <Card key={label} padding="sm">
            <p className="text-caption text-neutral-400 uppercase tracking-wide">{label}</p>
            <p className="font-semibold text-body-md text-neutral-900 dark:text-neutral-100 mt-1">{value}</p>
          </Card>
        ))}
      </div>
    </div>
  )
}

function SettingsDashSection() {
  return (
    <div className="space-y-6">
      <h1 className="page-title text-2xl">Settings</h1>
      <Card>
        <h2 className="font-semibold text-heading-md text-neutral-900 dark:text-neutral-100 mb-4">Preferences</h2>
        <div className="space-y-4">
          {[
            { label: 'Appointment Reminders', desc: 'Get notified 1 day before your appointment', checked: true },
            { label: 'Medicine Reminders', desc: 'Daily medicine dose reminders', checked: true },
            { label: 'Report Notifications', desc: 'Notified when test reports are ready', checked: true },
            { label: 'Chat Notifications', desc: 'Instant messages from your doctor', checked: false },
          ].map(item => (
            <div key={item.label} className="flex items-start justify-between gap-4 py-3 border-b border-border-light dark:border-border-dark last:border-0">
              <div>
                <p className="font-medium text-body-md text-neutral-900 dark:text-neutral-100">{item.label}</p>
                <p className="text-body-sm text-neutral-500 dark:text-neutral-400">{item.desc}</p>
              </div>
              <button className={cn('w-11 h-6 rounded-full transition-colors duration-200 flex-shrink-0',
                item.checked ? 'bg-accent-500' : 'bg-neutral-300 dark:bg-neutral-700'
              )}>
                <div className={cn('w-5 h-5 rounded-full bg-white shadow transform transition-transform duration-200',
                  item.checked ? 'translate-x-5.5' : 'translate-x-0.5'
                )} />
              </button>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}

/* ─── Section Map ─── */
const SECTIONS: Record<string, ReactNode> = {
  dashboard: <DashboardHome />,
  appointments: <AppointmentsSection />,
  queue: <QueueSection />,
  medicines: <MedicinesSection />,
  reports: <ReportsSection />,
  chat: <ChatSection />,
  notifications: <NotificationsSection />,
  profile: <ProfileSection />,
  settings: <SettingsDashSection />,
}

/* ─── Patient Dashboard ─── */
export default function PatientDashboard() {
  const [activeSection, setActiveSection] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { fetchAppointments, fetchTodayQueue, subscribeToQueue } = useAppointmentStore()
  const { fetchPrescriptions, fetchRecords } = useMedicalStore()

  useEffect(() => {
    fetchAppointments()
    fetchTodayQueue()
    fetchPrescriptions()
    fetchRecords()
    const unsub = subscribeToQueue()
    return () => unsub()
  }, [fetchAppointments, fetchTodayQueue, fetchPrescriptions, fetchRecords, subscribeToQueue])

  const currentNav = NAV_ITEMS.find(n => n.id === activeSection)

  return (
    <div className="min-h-screen bg-cream-100 dark:bg-neutral-950 flex">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block w-64 flex-shrink-0 sticky top-0 h-screen">
        <Sidebar active={activeSection} onNavigate={setActiveSection} />
      </div>

      {/* Mobile Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm lg:hidden"
              onClick={() => setSidebarOpen(false)}
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ duration: 0.3, ease: [0.25, 1, 0.5, 1] }}
              className="fixed inset-y-0 left-0 z-50 w-64 lg:hidden"
            >
              <Sidebar active={activeSection} onNavigate={setActiveSection} onClose={() => setSidebarOpen(false)} />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="sticky top-0 z-30 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-xl border-b border-border-light dark:border-border-dark px-4 sm:px-6 h-14 flex items-center gap-4">
          <button
            className="lg:hidden p-1.5 rounded-lg text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu size={20} />
          </button>
          <h2 className="font-manrope font-semibold text-neutral-900 dark:text-neutral-100">
            {currentNav?.label}
          </h2>
          <div className="ml-auto flex items-center gap-2">
            <button className="p-1.5 rounded-xl text-neutral-500 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors relative">
              <Bell size={18} />
              <span className="absolute top-0.5 right-0.5 w-2 h-2 rounded-full bg-rose-500" />
            </button>
            <Link to="/" className="text-caption text-neutral-400 hover:text-accent-500 transition-colors hidden sm:block">
              ← Back to Site
            </Link>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.25, ease: [0.25, 1, 0.5, 1] }}
            >
              {SECTIONS[activeSection]}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  )
}
