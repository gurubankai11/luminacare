import { useState } from 'react'
import { motion } from 'framer-motion'
import { Link, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard, Users, UserCheck, BarChart2, DollarSign,
  MapPin, Settings, Shield, LogOut, Menu, X, Bell, TrendingUp,
  UserPlus, Activity, Building2, MoreHorizontal
} from 'lucide-react'
import { Avatar, Badge } from '../../components/ui'
import Card, { StatCard } from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import { cn } from '../../lib/utils'
import { useAuthStore } from '../../stores/authStore'
import { supabase } from '../../lib/supabase'
import SystemModule from '../../components/admin/SystemModule'
import DataBox from '../../components/admin/DataBox'
import { useEffect } from 'react'

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'doctors', label: 'Doctors', icon: UserCheck },
  { id: 'staff', label: 'Staff', icon: Users },
  { id: 'patients', label: 'Patients', icon: Users },
  { id: 'analytics', label: 'Analytics', icon: BarChart2 },
  { id: 'revenue', label: 'Revenue', icon: DollarSign },
  { id: 'branches', label: 'Branches', icon: Building2 },
  { id: 'permissions', label: 'Permissions', icon: Shield },
  { id: 'settings', label: 'Settings', icon: Settings },
]



function AdminSidebar({ active, onNavigate, onClose }: { active: string; onNavigate: (id: string) => void; onClose?: () => void }) {
  const { signOut } = useAuthStore()
  const navigate = useNavigate()
  return (
    <div className="flex flex-col h-full bg-neutral-950 text-white">
      <div className="p-5 border-b border-neutral-800 flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-xl bg-purple-500 flex items-center justify-center">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M12 2L4 7V17L12 22L20 17V7L12 2Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /><path d="M12 8V16M8 12H16" stroke="white" strokeWidth="2" strokeLinecap="round" /></svg>
        </div>
        <span className="font-manrope font-bold text-base text-white">LuminaCare Admin</span>
        {onClose && <button onClick={onClose} className="ml-auto text-neutral-500 hover:text-white"><X size={16} /></button>}
      </div>
      <div className="px-4 py-4 border-b border-neutral-800 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-purple-500/20 flex items-center justify-center"><Shield size={16} className="text-purple-400" /></div>
        <div><p className="font-semibold text-body-sm text-white">System Admin</p><p className="text-caption text-purple-400">Super Admin</p></div>
      </div>
      <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
        {NAV_ITEMS.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => { onNavigate(id); onClose?.() }}
            className={cn('w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-body-sm font-medium transition-all duration-200',
              active === id ? 'bg-purple-500/20 text-purple-300' : 'text-neutral-400 hover:bg-neutral-800 hover:text-white'
            )}>
            <Icon size={16} />{label}
          </button>
        ))}
      </nav>
      <div className="p-3 border-t border-neutral-800">
        <button onClick={async () => { await signOut(); navigate('/') }}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-body-sm text-rose-400 hover:bg-rose-500/10 transition-all">
          <LogOut size={16} />Sign Out
        </button>
      </div>
    </div>
  )
}

function AdminDashboardHome({ doctors }: { doctors: any[] }) {
  const STATS = [
    { label: 'Total Patients', value: '15,234', change: '+234 this month', changeType: 'up' as const, icon: <Users size={20} /> },
    { label: 'Active Doctors', value: '38', change: '2 on leave', changeType: 'neutral' as const, icon: <UserCheck size={20} /> },
    { label: 'Monthly Revenue', value: '₹12.4L', change: '+18% vs last month', changeType: 'up' as const, icon: <DollarSign size={20} /> },
    { label: 'Branches', value: '8', change: '1 expansion planned', changeType: 'neutral' as const, icon: <Building2 size={20} /> },
    { label: "Today's Appointments", value: '142', change: '+12 walk-ins', changeType: 'up' as const, icon: <Activity size={20} /> },
    { label: 'Satisfaction Score', value: '4.9★', change: '312 new reviews', changeType: 'up' as const, icon: <TrendingUp size={20} /> },
  ]
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-manrope font-bold text-display-sm text-neutral-900 dark:text-neutral-100">Admin Overview</h1>
          <p className="text-body-md text-neutral-500 dark:text-neutral-400 mt-1">LuminaCare — System Dashboard</p>
        </div>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {STATS.map(s => <StatCard key={s.label} {...s} />)}
      </div>
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Doctor performance */}
        <Card>
          <h2 className="font-semibold text-heading-md text-neutral-900 dark:text-neutral-100 mb-4">Top Doctors This Month</h2>
          <div className="space-y-3">
            {doctors.slice(0, 4).map((doc, i) => (
              <div key={doc.id} className="flex items-center gap-3">
                <span className="text-body-sm font-bold text-neutral-400 w-5">{i + 1}</span>
                <Avatar name={doc.name || ''} src={doc.avatar_url} size="sm" />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-body-sm text-neutral-900 dark:text-neutral-100 truncate">{doc.name}</p>
                  <p className="text-caption text-neutral-400">{doc.specialty}</p>
                </div>
                <span className="text-body-sm font-semibold text-neutral-700 dark:text-neutral-300">Active</span>
              </div>
            ))}
          </div>
        </Card>
        {/* Revenue chart */}
        <Card>
          <h2 className="font-semibold text-heading-md text-neutral-900 dark:text-neutral-100 mb-4">Revenue — Last 6 Months</h2>
          <div className="flex items-end gap-2 h-28">
            {[8.2, 9.1, 10.4, 11.2, 10.8, 12.4].map((v, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <span className="text-xs text-neutral-400">₹{v}L</span>
                <div className="w-full bg-purple-200 dark:bg-purple-500/30 hover:bg-purple-500 transition-colors rounded-t-md" style={{ height: `${(v / 12.4) * 90}%` }} />
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2">
            {['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'].map(m => (
              <span key={m} className="text-xs text-neutral-400 flex-1 text-center">{m}</span>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}

function DoctorsSection({ doctors }: { doctors: any[] }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="page-title text-2xl">Doctors</h1>
        <Button variant="primary" size="sm" leftIcon={<UserPlus size={14} />}>Add Doctor</Button>
      </div>
      <div className="space-y-3">
        {doctors.map(doc => (
          <Card key={doc.id} className="flex items-center gap-4 flex-wrap">
            <Avatar name={doc.name || ''} src={doc.avatar_url} size="md" />
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-neutral-900 dark:text-neutral-100">{doc.name}</p>
              <p className="text-body-sm text-neutral-500">{doc.specialty || 'General'}</p>
            </div>
            <span className="text-body-sm text-neutral-600 dark:text-neutral-400">Active</span>
            <Badge variant="success" dot>Active</Badge>
            <button className="p-1.5 rounded-lg text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors">
              <MoreHorizontal size={16} />
            </button>
          </Card>
        ))}
      </div>
    </div>
  )
}

function BranchesSection({ branches }: { branches: any[] }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="page-title text-2xl">Branches</h1>
        <Button variant="primary" size="sm" leftIcon={<MapPin size={14} />}>Add Branch</Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {branches.map(b => (
          <Card key={b.id} className="hover:shadow-soft-md transition-shadow cursor-pointer">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-500/10 flex items-center justify-center"><Building2 size={20} className="text-purple-500" /></div>
              <Badge variant={b.status === 'open' ? 'success' : 'warning'} dot>{b.status}</Badge>
            </div>
            <h3 className="font-semibold text-heading-md text-neutral-900 dark:text-neutral-100">{b.name}</h3>
            <div className="grid grid-cols-3 gap-3 mt-4">
              <div><p className="text-caption text-neutral-400">Patients</p><p className="font-bold text-body-md text-neutral-900 dark:text-neutral-100">{b.patients?.toLocaleString() || 0}</p></div>
              <div><p className="text-caption text-neutral-400">Doctors</p><p className="font-bold text-body-md text-neutral-900 dark:text-neutral-100">{b.doctors || 0}</p></div>
              <div><p className="text-caption text-neutral-400">Revenue</p><p className="font-bold text-body-md text-neutral-900 dark:text-neutral-100">{b.revenue || '₹0L'}</p></div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}

export default function AdminDashboard() {
  const [active, setActive] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [doctors, setDoctors] = useState<any[]>([])
  const [branches, setBranches] = useState<any[]>([])
  
  useEffect(() => {
    supabase.from('profiles').select('*').eq('role', 'doctor').then(({ data }) => {
      if (data && data.length > 0) {
        setDoctors(data)
      }
    })

    supabase.from('branches').select('*').then(({ data }) => {
      if (data && data.length > 0) {
        setBranches(data)
      }
    })
  }, [])

  const currentNav = NAV_ITEMS.find(n => n.id === active)

  const ADMIN_SECTIONS: Record<string, React.ReactNode> = {
    dashboard: <AdminDashboardHome doctors={doctors} />,
    doctors: <DoctorsSection doctors={doctors} />,
    branches: <BranchesSection branches={branches} />,
    staff: <div className="p-8 text-neutral-500 text-center">Staff management section</div>,
    patients: <div className="p-8 text-neutral-500 text-center">Patient records section</div>,
    analytics: <DataBox />,
    revenue: <div className="p-8 text-neutral-500 text-center">Revenue analytics section</div>,
    permissions: <div className="p-8 text-neutral-500 text-center">Role & permissions management</div>,
    settings: (
      <div className="space-y-8">
        <SystemModule />
        <div className="p-8 text-neutral-500 text-center">System settings</div>
      </div>
    ),
  }

  return (
    <div className="min-h-screen bg-cream-100 dark:bg-neutral-950 flex">
      <div className="hidden lg:block w-64 flex-shrink-0 sticky top-0 h-screen">
        <AdminSidebar active={active} onNavigate={setActive} />
      </div>
      {sidebarOpen && (
        <>
          <div className="fixed inset-0 z-40 bg-black/40 lg:hidden" onClick={() => setSidebarOpen(false)} />
          <div className="fixed inset-y-0 left-0 z-50 w-64 lg:hidden"><AdminSidebar active={active} onNavigate={setActive} onClose={() => setSidebarOpen(false)} /></div>
        </>
      )}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-xl border-b border-border-light dark:border-border-dark px-4 sm:px-6 h-14 flex items-center gap-4">
          <button className="lg:hidden p-1.5 rounded-lg text-neutral-600 hover:bg-neutral-100 dark:hover:bg-neutral-800" onClick={() => setSidebarOpen(true)}><Menu size={20} /></button>
          <h2 className="font-manrope font-semibold text-neutral-900 dark:text-neutral-100">{currentNav?.label}</h2>
          <div className="ml-auto flex items-center gap-2">
            <button className="p-1.5 rounded-xl text-neutral-500 relative"><Bell size={18} /><span className="absolute top-0.5 right-0.5 w-2 h-2 rounded-full bg-rose-500" /></button>
            <Link to="/" className="text-caption text-neutral-400 hover:text-accent-500 hidden sm:block">← Back to Site</Link>
          </div>
        </header>
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          <motion.div key={active} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }}>
            {ADMIN_SECTIONS[active]}
          </motion.div>
        </main>
      </div>
    </div>
  )
}
