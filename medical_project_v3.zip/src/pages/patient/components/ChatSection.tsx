import { useState, useEffect, type ReactNode } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Link, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard, Calendar, Clock, Pill, FileText, MessageSquare,
  Bell, Settings, User, LogOut, Activity,
  CheckCircle, AlertCircle, XCircle, Download, Send, Paperclip,
  Menu, X
} from 'lucide-react'
import { useAuthStore } from '../../../stores/authStore'
import { Avatar, Badge } from '../../../components/ui'
import Card, { StatCard } from '../../../components/ui/Card'
import Button from '../../../components/ui/Button'
import Input from '../../../components/ui/Input'
import { useChatStore } from '../../../stores/chatStore'
import { useNotificationStore } from '../../../stores/notificationStore'
import { useAppointmentStore } from '../../../stores/appointmentStore'
import { useMedicalStore } from '../../../stores/medicalStore'
import { cn, formatDate, formatTime } from '../../../lib/utils'

const STATUS_CONFIG = {
  confirmed: { label: 'Confirmed', variant: 'accent' as const, icon: CheckCircle },
  completed: { label: 'Completed', variant: 'success' as const, icon: CheckCircle },
  pending: { label: 'Pending', variant: 'warning' as const, icon: AlertCircle },
  cancelled: { label: 'Cancelled', variant: 'danger' as const, icon: XCircle },
}

export function ChatSection() {
  const { messages, fetchMessages, sendMessage, subscribeToMessages } = useChatStore()
  const { user } = useAuthStore()
  const { appointments } = useAppointmentStore()
  const [message, setMessage] = useState('')

  const doctorId = appointments.find(a => a.doctor_id)?.doctor_id
  const doctorName = appointments.find(a => a.doctor_id)?.profiles?.name || 'Assigned Doctor'
  useEffect(() => {
    if (user?.id && doctorId) {
      fetchMessages(user.id, doctorId)
      const unsubscribe = subscribeToMessages(user.id, doctorId)
      return () => unsubscribe()
    }
  }, [fetchMessages, subscribeToMessages, user?.id, doctorId])

  const handleSend = () => {
    if (!message.trim() || !doctorId) return
    sendMessage(message, doctorId)
    setMessage('')
  }

  return (
    <div className="space-y-4 flex flex-col h-full">
      <h1 className="page-title text-2xl">Chat</h1>
      <Card className="flex-1 flex flex-col">
        <div className="flex items-center gap-3 pb-4 border-b border-border-light dark:border-border-dark">
          <Avatar name={doctorName} status="online" />
          <div>
            <p className="font-semibold text-neutral-900 dark:text-neutral-100">{doctorName}</p>
            <p className="text-caption text-emerald-500 flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />Online</p>
          </div>
        </div>

        <div className="flex-1 space-y-4 py-4 overflow-y-auto min-h-[300px] max-h-[400px]">
          {messages.map(msg => {
            const isMe = msg.sender_id === user?.id
            return (
              <div key={msg.message_id} className={cn('flex gap-3', isMe ? 'flex-row-reverse' : 'flex-row')}>
                {!isMe && <Avatar name={doctorName} size="sm" />}
                <div className={cn('max-w-xs rounded-2xl px-4 py-3 text-body-sm',
                  isMe
                    ? 'bg-accent-500 text-white rounded-tr-sm'
                    : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-900 dark:text-neutral-100 rounded-tl-sm'
                )}>
                  <p>{msg.message}</p>
                  <p className={cn('text-xs mt-1', isMe ? 'text-blue-100' : 'text-neutral-400')}>{formatTime(msg.created_at)}</p>
                </div>
              </div>
            )
          })}
        </div>

        <div className="flex items-center gap-2 pt-4 border-t border-border-light dark:border-border-dark">
          <button className="p-2 rounded-xl text-neutral-400 hover:text-accent-500 hover:bg-accent-50 dark:hover:bg-accent-500/10 transition-colors">
            <Paperclip size={18} />
          </button>
          <div className="flex-1">
            <Input
              placeholder="Type a message..."
              value={message}
              onChange={e => setMessage(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSend()}
            />
          </div>
          <Button variant="primary" size="sm" className="rounded-xl" rightIcon={<Send size={14} />} onClick={handleSend}>
            Send
          </Button>
        </div>
      </Card>
    </div>
  )
}