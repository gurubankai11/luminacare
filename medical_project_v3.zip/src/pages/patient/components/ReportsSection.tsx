import { useState, useEffect, type ReactNode } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Link, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard, Calendar, Clock, Pill, FileText, MessageSquare,
  Bell, Settings, User, LogOut, Activity,
  CheckCircle, AlertCircle, XCircle, Download, Send, Paperclip,
  Menu, X
} from 'lucide-react'
import { useAuthStore } from '../../../stores/authStore'
import { Avatar, Badge } from '../../../components/ui'
import Card, { StatCard } from '../../../components/ui/Card'
import Button from '../../../components/ui/Button'
import Input from '../../../components/ui/Input'
import { useChatStore } from '../../../stores/chatStore'
import { useNotificationStore } from '../../../stores/notificationStore'
import { useAppointmentStore } from '../../../stores/appointmentStore'
import { useMedicalStore } from '../../../stores/medicalStore'
import { cn, formatDate, formatTime } from '../../../lib/utils'

const STATUS_CONFIG = {
  confirmed: { label: 'Confirmed', variant: 'accent' as const, icon: CheckCircle },
  completed: { label: 'Completed', variant: 'success' as const, icon: CheckCircle },
  pending: { label: 'Pending', variant: 'warning' as const, icon: AlertCircle },
  cancelled: { label: 'Cancelled', variant: 'danger' as const, icon: XCircle },
}

export function ReportsSection() {
  const { records } = useMedicalStore()
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="page-title text-2xl">Test Reports</h1>
        <Button variant="outline" size="sm">Upload Report</Button>
      </div>
      <div className="space-y-3">
        {records.map(report => (
          <Card key={report.report_id} className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-accent-50 dark:bg-accent-500/10 flex items-center justify-center flex-shrink-0">
              <FileText size={22} className="text-accent-500" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-neutral-900 dark:text-neutral-100">{report.file}</p>
              <p className="text-body-sm text-neutral-500 dark:text-neutral-400">{report.report_type} · {formatDate(report.created_at)}</p>
            </div>
            <Badge variant={report.status === 'normal' ? 'success' : 'warning'} dot>
              {report.status === 'normal' ? 'Normal' : 'Review'}
            </Badge>
            <Button variant="ghost" size="sm" leftIcon={<Download size={13} />}>PDF</Button>
          </Card>
        ))}
        {records.length === 0 && <p className="text-neutral-500 py-4">No reports found.</p>}
      </div>
    </div>
  )
}