import { create } from 'zustand'
import { supabase } from '../lib/supabase'
import { useAuthStore } from './authStore'

export interface Appointment {
  appointment_id: string
  patient_id: string
  doctor_id: string
  department?: string
  hospital_branch?: string
  date: string
  time: string
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled' | 'in_progress'
  queue_token: number
  symptoms: string
  notes?: string
  created_at: string
  profiles?: { name: string, avatar_url: string } // Patient or Doctor details
}

interface AppointmentStore {
  appointments: Appointment[]
  todayQueue: Appointment[]
  isLoading: boolean
  fetchAppointments: () => Promise<void>
  fetchTodayQueue: () => Promise<void>
  updateStatus: (appointment_id: string, status: Appointment['status']) => Promise<void>
  bookAppointment: (data: Partial<Appointment>) => Promise<Appointment | void>
  subscribeToQueue: () => (() => void)
}

export const useAppointmentStore = create<AppointmentStore>((set, get) => ({
  appointments: [],
  todayQueue: [],
  isLoading: false,

  fetchAppointments: async () => {
    const user = useAuthStore.getState().user
    if (!user) return

    set({ isLoading: true })
    try {
      const isDoctor = user.role === 'doctor' || user.role === 'admin'
      const column = isDoctor ? 'doctor_id' : 'patient_id'

      const { data, error } = await supabase
        .from('appointments')
        .select('*, profiles(name, avatar_url)')
        .eq(column, user.id)
        .order('date', { ascending: true })
        .order('time', { ascending: true })

      if (error) throw error
      set({ appointments: data as unknown as Appointment[] })
    } catch (error) {
      console.error('Error fetching appointments:', error)
    } finally {
      set({ isLoading: false })
    }
  },

  fetchTodayQueue: async () => {
    const user = useAuthStore.getState().user
    if (!user) return

    set({ isLoading: true })
    try {
      const isDoctor = user.role === 'doctor' || user.role === 'admin'
      const column = isDoctor ? 'doctor_id' : 'patient_id'
      const today = new Date().toISOString().split('T')[0]

      const { data, error } = await supabase
        .from('appointments')
        .select('*, profiles(name, avatar_url)')
        .eq(column, user.id)
        .eq('date', today)
        .order('queue_token', { ascending: true })

      if (error) throw error
      set({ todayQueue: data as unknown as Appointment[] })
    } catch (error) {
      console.error('Error fetching today queue:', error)
    } finally {
      set({ isLoading: false })
    }
  },

  updateStatus: async (appointment_id, status) => {
    try {
      const { error } = await supabase
        .from('appointments')
        .update({ status })
        .eq('appointment_id', appointment_id)
      if (error) throw error
      
      set(state => ({
        appointments: state.appointments.map(a => a.appointment_id === appointment_id ? { ...a, status } : a),
        todayQueue: state.todayQueue.map(a => a.appointment_id === appointment_id ? { ...a, status } : a)
      }))
    } catch (error) {
      console.error('Error updating status:', error)
    }
  },

  bookAppointment: async (data) => {
    const user = useAuthStore.getState().user
    if (!user) return

    try {
      const { data: newAppointment, error } = await supabase
        .from('appointments')
        .insert([{ 
          ...data, 
          patient_id: user.id, 
          status: 'pending',
          queue_token: Math.floor(Math.random() * 100) + 1 // Generate a simple queue token for demo
        }])
        .select()
        .single()
        
      if (error) throw error
      
      // Send notification to doctor
      if (data.doctor_id) {
        await supabase.from('notifications').insert({
          user_id: data.doctor_id,
          title: 'New Appointment',
          message: `You have a new appointment request for ${data.date} at ${data.time}`,
          type: 'appointment',
          read: false
        })
      }
      
      await get().fetchAppointments()
      return newAppointment as Appointment
    } catch (error) {
      console.error('Error booking appointment:', error)
      throw error // Re-throw so UI can catch it
    }
  },

  subscribeToQueue: () => {
    const user = useAuthStore.getState().user
    if (!user) return () => {}
    
    const isDoctor = user.role === 'doctor' || user.role === 'admin'
    const column = isDoctor ? 'doctor_id' : 'patient_id'

    const channel = supabase.channel(`queue_${user.id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'appointments', filter: `${column}=eq.${user.id}` },
        () => {
          get().fetchTodayQueue()
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }
}))
