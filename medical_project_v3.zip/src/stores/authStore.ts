import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { supabase } from '../lib/supabase'

type UserRole = 'patient' | 'doctor' | 'reception' | 'admin'

interface User {
  id: string
  email: string
  name: string | null
  phone: string | null
  role: UserRole
  avatar_url: string | null
  blood_group?: string | null
  height?: number | null
  weight?: number | null
  allergies?: string[] | null
  medical_history?: string | null
  insurance?: { provider: string, id: string } | null
  emergency_contact?: { name: string, phone: string } | null
  gender?: 'male' | 'female' | 'other' | null
  age?: number | null
  dob?: string | null
  address?: string | null
  theme?: 'light' | 'dark' | 'system'
  language?: string
}

interface AuthStore {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
  setUser: (user: User | null) => void
  setLoading: (loading: boolean) => void
  signIn: (email: string, password: string) => Promise<{ error: string | null }>
  signInWithGoogle: () => Promise<{ error: string | null }>
  resetPassword: (email: string) => Promise<{ error: string | null }>
  signOut: () => Promise<void>
  signUp: (email: string, password: string, fullName: string, role: UserRole) => Promise<{ error: string | null }>
  refreshUser: () => Promise<void>
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      isLoading: false,
      isAuthenticated: false,

      setUser: (user) => set({ user, isAuthenticated: !!user }),
      setLoading: (isLoading) => set({ isLoading }),

      signIn: async (email, password) => {
        set({ isLoading: true })
        


        try {
          const { data, error } = await supabase.auth.signInWithPassword({ email, password })
          if (error) {
            set({ isLoading: false })
            return { error: error.message }
          }
          if (data.user) {
            const { data: profile } = await supabase
              .from('profiles')
              .select('*')
              .eq('id', data.user.id)
              .single()
            if (profile) {
              set({ user: profile as User, isAuthenticated: true, isLoading: false })
            } else {
               // Fallback if profile doesn't exist yet
               set({ user: { id: data.user.id, email, name: null, phone: null, role: 'patient', avatar_url: null, theme: 'system', language: 'en' }, isAuthenticated: true, isLoading: false })
            }
          }
          return { error: null }
        } catch {
          set({ isLoading: false })
          return { error: 'An unexpected error occurred' }
        }
      },

      signInWithGoogle: async () => {
        set({ isLoading: true })
        try {
          const { error } = await supabase.auth.signInWithOAuth({
            provider: 'google',
            options: {
              redirectTo: window.location.origin + '/dashboard/patient',
            }
          })
          if (error) {
            set({ isLoading: false })
            return { error: error.message }
          }
          return { error: null }
        } catch {
          set({ isLoading: false })
          return { error: 'An unexpected error occurred' }
        }
      },

      resetPassword: async (email) => {
        set({ isLoading: true })
        try {
          const { error } = await supabase.auth.resetPasswordForEmail(email, {
            redirectTo: window.location.origin + '/update-password',
          })
          set({ isLoading: false })
          return { error: error ? error.message : null }
        } catch {
          set({ isLoading: false })
          return { error: 'An unexpected error occurred' }
        }
      },

      signOut: async () => {
        await supabase.auth.signOut()
        set({ user: null, isAuthenticated: false })
      },

      signUp: async (email, password, fullName, role) => {
        set({ isLoading: true })
        try {
          const { data, error } = await supabase.auth.signUp({ email, password })
          if (error) {
            set({ isLoading: false })
            return { error: error.message }
          }
          if (data.user) {
            await supabase.from('profiles').insert({
              id: data.user.id,
              email,
              name: fullName,
              role,
            })
          }
          set({ isLoading: false })
          return { error: null }
        } catch {
          set({ isLoading: false })
          return { error: 'An unexpected error occurred' }
        }
      },

      refreshUser: async () => {
        const { data: { session } } = await supabase.auth.getSession()
        if (!session?.user) {
          set({ user: null, isAuthenticated: false })
          return
        }
        
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single()
          
        if (profile) {
          set({ user: profile as User, isAuthenticated: true })
        } else {
           // Create a fallback profile in state if it hasn't been created yet
           set({ 
             user: { 
               id: session.user.id, 
               email: session.user.email || '', 
               name: session.user.user_metadata?.full_name || null, 
               phone: null, 
               role: 'patient', 
               avatar_url: session.user.user_metadata?.avatar_url || null, 
               theme: 'system', 
               language: 'en' 
             }, 
             isAuthenticated: true 
           })
        }
      },
    }),
    {
      name: 'lumina-auth',
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
)
