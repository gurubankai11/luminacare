import { create } from 'zustand'
import { supabase } from '../lib/supabase'
import { useAuthStore } from './authStore'

export interface Prescription {
  prescription_id: string
  patient_id: string
  doctor_id: string
  medicine: any[]
  dosage: string | null
  instructions: string
  pdf_url: string | null
  created_at: string
  profiles?: { name: string }
}

export interface MedicalRecord {
  report_id: string
  patient_id: string
  doctor_id: string | null
  file: string
  report_type: string | null
  status: string
  created_at: string
}

interface MedicalStore {
  prescriptions: Prescription[]
  records: MedicalRecord[]
  isLoading: boolean
  fetchPrescriptions: () => Promise<void>
  fetchRecords: () => Promise<void>
  addPrescription: (data: Partial<Prescription>) => Promise<void>
}

export const useMedicalStore = create<MedicalStore>((set, get) => ({
  prescriptions: [],
  records: [],
  isLoading: false,

  fetchPrescriptions: async () => {
    const user = useAuthStore.getState().user
    if (!user) return

    set({ isLoading: true })
    try {
      const isDoctor = user.role === 'doctor' || user.role === 'admin'
      const column = isDoctor ? 'doctor_id' : 'patient_id'

      const { data, error } = await supabase
        .from('prescriptions')
        .select('*, profiles(name)')
        .eq(column, user.id)
        .order('created_at', { ascending: false })

      if (error) throw error
      set({ prescriptions: data as unknown as Prescription[] })
    } catch (error) {
      console.error('Error fetching prescriptions:', error)
    } finally {
      set({ isLoading: false })
    }
  },

  fetchRecords: async () => {
    const user = useAuthStore.getState().user
    if (!user) return

    set({ isLoading: true })
    try {
      const { data, error } = await supabase
        .from('reports')
        .select('*')
        .eq('patient_id', user.id)
        .order('created_at', { ascending: false })

      if (error) throw error
      set({ records: data as MedicalRecord[] })
    } catch (error) {
      console.error('Error fetching records:', error)
    } finally {
      set({ isLoading: false })
    }
  },

  addPrescription: async (data) => {
    const user = useAuthStore.getState().user
    if (!user) return

    try {
      const { error } = await supabase.from('prescriptions').insert([{
        doctor_id: user.id,
        patient_id: data.patient_id,
        medicine: (data as any).medicines || [],
        dosage: 'See medicines',
        instructions: `Diagnosis: ${(data as any).diagnosis || 'N/A'}\n\n${data.instructions || ''}`
      }])
      if (error) throw error
      await get().fetchPrescriptions()
    } catch (error) {
      console.error('Error adding prescription:', error)
      throw error
    }
  }
}))
